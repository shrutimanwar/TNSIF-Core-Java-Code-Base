function rollDice() {
  const diceImages = [
  "images/dice1.png",
  "images/dice2.png",
  "images/dice3.png",
  "images/dice4.png",
  "images/dice5.png",
  "images/dice6.png"
];

  const rolls = [];

  // Reset styles
  for (let i = 1; i <= 4; i++) {
    document.getElementById(`player${i}`).classList.remove("winner");
  }

  for (let i = 1; i <= 4; i++) {
    const roll = Math.floor(Math.random() * 6) + 1;
    rolls.push(roll);

    const dice = document.getElementById(`dice${i}`);

    // Add animation class
    dice.classList.add("animate-roll");

    // After animation ends, update image
    setTimeout(() => {
      dice.src = diceImages[roll - 1];
      dice.classList.remove("animate-roll");
    }, 600);
  }

  // Show result after animation
  setTimeout(() => {
    const max = Math.max(...rolls);
    const winners = [];

    rolls.forEach((roll, index) => {
      if (roll === max) {
        winners.push(index + 1);
      }
    });

    const resultText = winners.length === 1
      ? `🏆 Player ${winners[0]} Wins!`
      : `🤝 It's a draw between Player(s): ${winners.join(", ")}`;

    document.getElementById("result").innerText = resultText;

    // Highlight winner(s)
    winners.forEach(playerNum => {
      document.getElementById(`player${playerNum}`).classList.add("winner");
    });
  }, 700); // wait till animation completes
}
